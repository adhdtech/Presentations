
-- Show data
SELECT * FROM FamilyMembers
SELECT * FROM Food
SELECT * FROM Habits

SELECT * FROM PersonHabits
SELECT * FROM EatenFood
SELECT * FROM FavoriteFood
SELECT * FROM Arrests


-- Most common habits
SELECT HabitName, COUNT(*) AS Total
FROM Habits H, PersonHabits PH
WHERE H.HabitID = PH.HabitID
GROUP BY HabitName
ORDER BY COUNT(*) DESC;



-- Most popular foods
SELECT HabitName, COUNT(*) AS Total
FROM Habits H, PersonHabits PH
WHERE H.HabitID = PH.HabitID
GROUP BY HabitName
ORDER BY COUNT(*) DESC;


/*
-- Create Node tables
  CREATE TABLE [dbo].[FamilyMembers_Node](
         [PersonID] int NOT NULL,
         [Name] nvarchar(max) NOT NULL,
		 [Age] int NOT NULL,
		 [Role] nvarchar(max) NOT NULL 
  )
  AS NODE;

  CREATE TABLE [dbo].[Food_Node](
         [FoodID] int NOT NULL,
         [FoodName] nvarchar(50) NOT NULL
  )
  AS NODE;

  CREATE TABLE [dbo].[Habits_Node](
         [HabitID] int NOT NULL,
         [HabitName] nvarchar(50) NOT NULL
  )
  AS NODE;

-- Create Edge tables
CREATE TABLE [dbo].[Likes]
AS EDGE;
   
CREATE TABLE [dbo].[Exhibits]
AS EDGE;
*/

/*
-- Merge Node tables
MERGE INTO dbo.FamilyMembers_Node AS FMN
USING(SELECT * FROM dbo.FamilyMembers) as FM 
	ON FM.PersonID=FMN.PersonID
WHEN MATCHED THEN
	UPDATE SET FMN.[Name] = FM.[Name], FMN.Age = FM.Age, FMN.[Role] = FM.[Role]
WHEN NOT MATCHED THEN
	INSERT (PersonID, [Name], Age, [Role])
        VALUES (FM.PersonID, FM.[Name], FM.Age, FM.[Role]);

MERGE INTO dbo.Food_Node AS FN
USING(SELECT * FROM dbo.Food) as F
	ON F.FoodID=FN.FoodID
WHEN MATCHED THEN
	UPDATE SET FN.[FoodName] = F.[FoodName]
WHEN NOT MATCHED THEN
	INSERT (FoodID, [FoodName])
        VALUES (F.FoodID, F.[FoodName]);

MERGE INTO dbo.Habits_Node AS HN
USING(SELECT * FROM dbo.Habits) as H
	ON H.HabitID=HN.HabitID
WHEN MATCHED THEN
	UPDATE SET HN.[HabitName] = H.[HabitName]
WHEN NOT MATCHED THEN
	INSERT (HabitID, [HabitName])
        VALUES (H.HabitID, H.[HabitName]);
*/

/*
-- Merge Edges
INSERT INTO Likes ($from_id, $to_id)
SELECT FM.$node_id , F.$node_id
	FROM FamilyMembers_Node FM, Food_Node F, FavoriteFood FF
	WHERE FM.PersonID = FF.PersonID
	AND FF.FoodID = F.FoodID;

INSERT INTO Exhibits ($from_id, $to_id)
SELECT FM.$node_id , H.$node_id
	FROM FamilyMembers_Node FM, Habits_Node H, PersonHabits PH
	WHERE FM.PersonID = PH.PersonID
	AND PH.HabitID = H.HabitID;
*/


-- Who likes what food: Traditional
SELECT FM.[Name], F.[FoodName]
FROM FamilyMembers FM, FavoriteFood FF, Food F
WHERE FM.PersonID = FF.PersonID
AND FF.FoodID = F.FoodID

-- Who likes what food: Graph
SELECT FamilyMembers_Node.[Name], Food_Node.[FoodName]
FROM FamilyMembers_Node, Likes, Food_Node
WHERE MATCH(FamilyMembers_Node-(Likes)->Food_Node)


-- Who has habits: Traditional
SELECT FM.[Name], H.[HabitName]
FROM FamilyMembers FM, PersonHabits PH, Habits H
WHERE FM.PersonID = PH.PersonID
AND PH.HabitID = H.HabitID

-- Who has habits: Graph
SELECT FamilyMembers_Node.[Name], Habits_Node.[HabitName]
FROM FamilyMembers_Node, Exhibits, Habits_Node
WHERE MATCH(FamilyMembers_Node-(Exhibits)->Habits_Node)


-- Who likes Chocolate and is a Night Owl: Traditional
SELECT FM.[Name]
FROM FamilyMembers FM, FavoriteFood FF, Food F, PersonHabits PH, Habits H
WHERE FM.PersonID = FF.PersonID
AND FF.FoodID = F.FoodID
AND FM.PersonID = PH.PersonID
AND PH.HabitID = H.HabitID
AND F.FoodName = 'Chocolate'
AND H.HabitName = 'Night Owl'

-- Who likes Chocolate and is a Night Owl: Graph
SELECT [Name]
FROM FamilyMembers_Node, Exhibits, Habits_Node, Likes, Food_Node
WHERE MATCH(Food_Node<-(Likes)-FamilyMembers_Node-(Exhibits)->Habits_Node)
AND Food_Node.FoodName = 'Chocolate'
AND Habits_Node.HabitName = 'Night Owl'