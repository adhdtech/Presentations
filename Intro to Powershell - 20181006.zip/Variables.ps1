﻿$myString = "This is a test string"

$myArray = 32,53,18,98

$myHash = @{
    FirstName = "Pete"
    LastName = "Brown"
}