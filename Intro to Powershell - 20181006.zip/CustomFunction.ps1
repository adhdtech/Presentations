function greetme {
    Param($personName)
    $outputText = "Hello " + $personName
    $outputText
}
greetme "Bob"

function queryToGrid {
    Param($sqlQuery)
    Invoke-Sqlcmd $sqlQuery | Out-GridView
}