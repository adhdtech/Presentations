﻿# Begin Recording
Start-Transcript

# List loaded modules
Get-Module

Import-Module SqlServer

# See commands provided by SqlServer module
Get-Command -Module SqlServer

# List objects in default instance on localhost
dir SQLSERVER:\SQL\localhost\DEFAULT

# List databases
dir SQLSERVER:\SQL\localhost\DEFAULT\Databases | Format-Table -AutoSize

# Create new database
$sqlInstance = Get-Item SQLSERVER:\SQL\localhost\DEFAULT
$familyDB = New-Object -TypeName Microsoft.SqlServer.Management.Smo.Database -argumentlist $sqlInstance, "FamilyDB"  
$familyDB.Create()

# Two ways to reference database object
$familyDB = Get-Item SQLSERVER:\SQL\localhost\DEFAULT\Databases\FamilyDB
$familyDB = $sqlInstance.Databases["FamilyDB"]  
$familyDB.CreateDate

# Two ways to drop database
$failyDB.Drop()
erase SQLSERVER:\SQL\localhost\DEFAULT\Databases\FamilyDB

# See commands related to tables
Get-Command | Where-Object {$_.Name -like "*table*"}

# Get family data
$myFamilyObj = Get-Content .\FamilyMembers.json | ConvertFrom-Json

# Insert records data into new table
Write-SqlTableData -ServerInstance localhost -DataBase FamilyDB -SchemaName dbo -TableName FamilyMembers -InputData $myFamilyObj -Force

# Read data
$familyMembersTable = Get-Item SQLSERVER:\SQL\localhost\DEFAULT\Databases\FamilyDB\Tables\dbo.FamilyMembers
Read-SqlTableData -InputObject $familyMembersTable

cd SQLSERVER:\SQL\localhost\DEFAULT\Databases\FamilyDB\Tables\dbo.FamilyMembers
Read-SqlTableData

# Get Volume Data
Get-Volume | select DriveLetter,FriendlyName,FileSystemType | Write-SqlTableData -ServerInstance localhost -DataBase FamilyDB -SchemaName dbo -TableName StorageVolumes -Force
# ... look at column defs ...

# Act like a fool and delete AdventureWorks
cd SQLSERVER:\SQL\localhost\DEFAULT\Databases
erase AdventureWorks2016CTP3_mod

# Look at AdventureWorks Backup File
Invoke-Sqlcmd "RESTORE FILELISTONLY FROM DISK = N'C:\Backups\AdventureWorks2016CTP3.bak'"

# Create custom function to make viewing easier
function queryToGrid {
    Param($sqlQuery)
    Invoke-Sqlcmd $sqlQuery | Out-GridView
}

queryToGrid "RESTORE FILELISTONLY FROM DISK = N'C:\Backups\AdventureWorks2016CTP3.bak'"

# Restore AdventureWorks
$RelocateLog= New-Object Microsoft.SqlServer.Management.Smo.RelocateFile("AdventureWorks2016CTP3_Log","C:\SQLServerData\AdventureWorks2016CTP3.ldf")
$RelocateData= New-Object Microsoft.SqlServer.Management.Smo.RelocateFile("AdventureWorks2016CTP3_Data","C:\SQLServerData\AdventureWorks2016CTP3.mdf")
$RelocateMod= New-Object Microsoft.SqlServer.Management.Smo.RelocateFile("AdventureWorks2016CTP3_mod","C:\SQLServerData\AdventureWorks2016CTP3.mod")
Restore-SqlDatabase -Database "AdventureWorks2016CTP3" -BackupFile "C:\Backups\AdventureWorks2016CTP3.bak" -RelocateFile @($RelocateData,$RelocateLog,$RelocateMod)

